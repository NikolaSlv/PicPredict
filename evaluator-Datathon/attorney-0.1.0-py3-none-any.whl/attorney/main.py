import attorney.variables as variables
import click
import sys
from multiprocessing import Process, Pipe
import logging

from InquirerPy import inquirer
from InquirerPy.base.control import Choice

import attorney.richter_api as richter
from attorney.ssh_tunnel.tunnel import Tunnel



@click.command()
@click.option('--debug/--no-debug', default=False)
def cli(debug):
    logging.basicConfig(
        level=(logging.DEBUG if debug else logging.INFO)
    )
    submit()


def submit():
    email = inquirer.text("Enter the email address that you will use with Devpost").execute()
    challenges = richter.get_challenges()
    challenge = inquirer.select(
        message="Which challenge do you want to submit to?",
        choices=[Choice(challenge_id, name=challenge_name) for challenge_id, challenge_name in challenges]
    ).execute()
    port = inquirer.number("Enter the port that your server is running on").execute()
    port = int(port)
    print(f"Challenge: {challenges[challenge][1]}")
    print(f"Port: {port}")
    proceed = inquirer.confirm(message="Proceed?", default=True).execute()
    if not proceed:
        print(f"Exiting...")
        sys.exit(0)

    parent_pipe, child_pipe = Pipe()
    tunnel_process = Process(
        target=Tunnel.create,
        args=(variables.REMOTE_ADDRESS, variables.SSH_PORT, variables.ssh_username, variables.ssh_password, port, child_pipe)
    )
    tunnel_process.start()

    remote_port = parent_pipe.recv()
    print(f"Binding local port {port} to remote port {remote_port} on richter")
    print("Starting Evaluation")

    # Block until Ctrl+C or judge finishes with response
    try:
        score = richter.request_judge(challenge, email, variables.REMOTE_ADDRESS, remote_port)
    except KeyboardInterrupt:
        logging.debug(f"Ctrl+C received")
        tunnel_process.kill()
        sys.exit(1)

    print(f"Evaluation Done. You scored {score}")
    tunnel_process.kill()
    sys.exit(0)


if __name__ == "__main__":
    cli()
