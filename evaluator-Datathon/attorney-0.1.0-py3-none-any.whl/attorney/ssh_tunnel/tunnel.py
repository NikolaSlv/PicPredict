import multiprocessing
import paramiko
import socket
import select
import threading
import sys
import logging

"""
        ┌──────────────────────────────────────────────┐       ┌───────────────────────────────────────────────────────┐
        │            Participant Machine               │       │                       Richter Cloud                   │
        │  ┌────────────────┐         ┌──────────┐     │       │    ┌─────────────────┐           ┌─────────────────┐  │
        │  │                ├────────►│          ├─────┴───────┼───►│                 ├──────────►│                 │  │
        │  │ localhost:5000 │ Socket  │ attorney │   SSH Tunnel│    │Remote SSH Server│ Some Port │Evaluator Script │  │
        │  │                │◄────────┤          │ ◄───┬───────┼────┤                 │◄──────────┤                 │  │
        │  └────────────────┘         └──────────┘     │       │    └─────────────────┘           └─────────────────┘  │
        │                                              │       │                                                       │
        └──────────────────────────────────────────────┘       └───────────────────────────────────────────────────────┘
"""


class Tunnel:
    def __init__(self, remote_address: str, ssh_port: int, username: str, password: str, local_port: int,
                 child_pipe: multiprocessing.Pipe):
        """
        Tunnel that bridges data from localhost to remote server over SSH and TCP/IP.
        Steps (See above comment for diagram):
            1. Establish SSH Connection to Server
            2. Request an available open port on the remote server
            3. Forward all TCP/IP data from the port on remote server to us over channel
            4. Read data in the channel and send it over to local server on their port
            5. Forward any response data back

        This should generally be run in a separate Process.

        :param remote_address: IP Address of the remote server
        :param ssh_port: SSH Port. Typically, 22
        :param username: SSH Username (this should be a user with no privs except TCP Forwarding)
        :param password: SSH Password
        :param local_port: The port where the local server is running
        :param child_pipe: Used to send data from tunnel back to main server
        """
        self.remote_port = None
        self.remote_address = remote_address
        self.local_port = local_port
        self.child_pipe = child_pipe

        # Create a separate logger for this process
        self.logger = multiprocessing.log_to_stderr()
        self.logger.setLevel(logging.INFO)

        self.client = paramiko.SSHClient()
        self.client.load_system_host_keys()
        self.client.set_missing_host_key_policy(paramiko.WarningPolicy)

        try:
            self.client.connect(remote_address, ssh_port, username=username, password=password)
        except Exception as e:
            self.logger.critical(f"Failed to connect to {username}@{remote_address}:{ssh_port}: {e}")
            sys.exit(1)
        self.tunnel()

    @classmethod
    def create(cls, remote_address: str, ssh_port: int, username: str, password: str, local_port: int,
               child_pipe: multiprocessing.Pipe):
        """
        Helper factory to make it easier to create Tunnel. For information on Tunnel and the params, check the docstring
        for the constructor
        """
        cls(remote_address, ssh_port, username, password, local_port, child_pipe)

    def tunnel(self):
        """
        Requests an open port from the server and then forwards new data from that remote port to us over SSH.
        Every time a request passes through, a channel is created that parses the data and sends it off.

        Sends port number over pipe back to main process
        """
        transport = self.client.get_transport()
        self.remote_port = transport.request_port_forward("", 0)
        self.child_pipe.send(self.remote_port)
        self.logger.debug(f"Forwarding Port {self.local_port} to {self.remote_port}")
        try:
            while True:
                chan = transport.accept(10)
                if chan is None:
                    continue
                thr = threading.Thread(
                    target=self.handle_channel,
                    args=[chan]
                )
                thr.daemon = True
                self.logger.debug(f"Launching Thread")
                thr.start()
        except KeyboardInterrupt:
            self.logger.debug("Ctrl+C")

    def handle_channel(self, chan: paramiko.Channel):
        """
        Creates a connection to the port on localhost and then transfers pipes remote data to local data.
        This should be running on it's on thread.

        :param chan: A (socket-like) Channel to the remote server over SSH
        """
        sock = socket.socket()
        try:
            sock.connect(("127.0.0.1", self.local_port))
        except ConnectionRefusedError:
            self.logger.critical(f"Connection Refused on Port {self.local_port}. "
                                 f"Are you sure your server is running at that port?")
            sys.exit(1)
        except Exception as e:
            self.logger.critical(f"Failed to connect to local port {self.local_port}: {e}")
            sys.exit(1)

        while True:
            r, w, x, = select.select([sock, chan], [], [])
            if sock in r:
                data = sock.recv(1024)
                if len(data) == 0:
                    break
                chan.send(data)

            if chan in r:
                data = chan.recv(1024)
                if len(data) == 0:
                    break
                sock.send(data)

        chan.close()
        sock.close()
        self.logger.debug("Tunnel closed")
