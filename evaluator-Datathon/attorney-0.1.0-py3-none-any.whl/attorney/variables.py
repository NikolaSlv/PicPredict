REMOTE_ADDRESS = "45.79.42.130"
SSH_PORT = 22
ssh_username="sshtunnel"
ssh_password="sshtunnel"
LEADERBOARD_URL="https://richter-ec4bd-default-rtdb.firebaseio.com/challenges/names.json"
ARICHTER_URL="http://127.0.0.1:5000/request_evaluator"
RICHTER_URL="https://richter-evaluator-2-ryd3bo7wyq-uc.a.run.app/request_evaluator"